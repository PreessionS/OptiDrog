	
0	
place_id	167628748
licence	"Data © OpenStreetMap contributors, ODbL 1.0. http://osm.org/copyright"
osm_type	"way"
osm_id	54965748
lat	"50.0988040"
lon	"20.0099408"
category	"landuse"
type	"residential"
place_rank	22
importance	0.10674603418020902
addresstype	"residential"
name	"Osiedle Bohaterów Września"
display_name	"Osiedle Bohaterów Września, Mistrzejowice, Kraków, województwo małopolskie, Polska"
boundingbox	
0	"50.0946506"
1	"50.1026806"
2	"20.0036370"
3	"20.0129514"

FIRMY

	
0	
place_id	406106159
licence	"Data © OpenStreetMap contributors, ODbL 1.0. http://osm.org/copyright"
osm_type	"way"
osm_id	911617892
lat	"54.7823487"
lon	"18.1725480"
category	"shop"
type	"convenience"
place_rank	30
importance	4.912108033870478e-05JS:0.00004912108033870478
addresstype	"shop"
name	"Żabka"
display_name	"Żabka, 1A, Długa, Minkowice, gmina Krokowa, powiat pucki, 84-110, Polska"
boundingbox	
0	"54.7822935"
1	"54.7824038"
2	"18.1723108"
3	"18.1727851"